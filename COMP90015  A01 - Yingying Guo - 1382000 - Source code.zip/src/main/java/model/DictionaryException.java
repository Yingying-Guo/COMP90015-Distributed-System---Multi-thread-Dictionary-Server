package model;

public class DictionaryException extends Exception{
    public DictionaryException(String s) {
        super(s);
    }
}
